<?php
// @codingStandardsIgnoreFile

/**
 * @file
 * Contains database additions to drupal-8.bare.standard.php.gz for testing the
 * upgrade path of https://www.drupal.org/node/2836157.
 */

use Drupal\Core\Database\Database;

$connection = Database::getConnection();

// Update modules lists.
$connection->insert('key_value')
  ->fields(array(
    'collection',
    'name',
    'value',
  ))
  ->values(array(
    'collection' => 'system.schema',
    'name' => 'sms',
    'value' => 'i:8000;',
  ))
  ->values(array(
    'collection' => 'system.schema',
    'name' => 'telephone',
    'value' => 'i:8000;',
  ))
  ->execute();

// Update modules list in state.
$files = $connection->select('key_value')
  ->fields('key_value', ['value'])
  ->condition('collection', 'state')
  ->condition('name', 'system.module.files')
  ->execute()
  ->fetchField();
$files = unserialize($files);
$files['dynamic_entity_reference'] = 'modules/dynamic_entity_reference/dynamic_entity_reference.info.yml';
$files['sms'] = 'modules/smsframework/sms.info.yml';
$connection->update('key_value')
  ->fields([
    'collection' => 'state',
    'name' => 'system.module.files',
    'value' => serialize($files),
  ])
  ->condition('collection', 'state')
  ->condition('name', 'system.module.files')
  ->execute();

// Update core.extension to incorporate the SMS module.
$extensions = $connection->select('config')
  ->fields('config', ['data'])
  ->condition('collection', '')
  ->condition('name', 'core.extension')
  ->execute()
  ->fetchField();
$extensions = unserialize($extensions);
$extensions['module']['sms'] = 0;
$extensions['module']['telephone'] = 0;
$extensions['module']['dynamic_entity_reference'] = 0;
$connection->update('config')
  ->fields([
    'collection' => '',
    'name' => 'core.extension',
    'data' => serialize($extensions),
  ])
  ->condition('collection', '')
  ->condition('name', 'core.extension')
  ->execute();

// Add SMS Framework entity types.
$connection->insert('key_value')
  ->fields(['collection', 'name', 'value'])
  ->values(array(
    'collection' => 'entity.definitions.installed',
    'name' => 'phone_number_settings.entity_type',
    'value' => 'O:42:"Drupal\Core\Config\Entity\ConfigEntityType":39:{s:16:" * config_prefix";s:5:"phone";s:15:" * static_cache";b:0;s:14:" * lookup_keys";a:1:{i:0;s:4:"uuid";}s:16:" * config_export";a:0:{}s:21:" * mergedConfigExport";a:0:{}s:15:" * render_cache";b:1;s:19:" * persistent_cache";b:1;s:14:" * entity_keys";a:7:{s:2:"id";s:2:"id";s:5:"label";s:2:"id";s:8:"revision";s:0:"";s:6:"bundle";s:0:"";s:8:"langcode";s:8:"langcode";s:16:"default_langcode";s:16:"default_langcode";s:4:"uuid";s:4:"uuid";}s:5:" * id";s:21:"phone_number_settings";s:11:" * provider";s:3:"sms";s:8:" * class";s:37:"Drupal\sms\Entity\PhoneNumberSettings";s:16:" * originalClass";N;s:11:" * handlers";a:5:{s:12:"list_builder";s:48:"\Drupal\sms\Lists\PhoneNumberSettingsListBuilder";s:4:"form";a:4:{s:3:"add";s:39:"Drupal\sms\Form\PhoneNumberSettingsForm";s:7:"default";s:39:"Drupal\sms\Form\PhoneNumberSettingsForm";s:4:"edit";s:39:"Drupal\sms\Form\PhoneNumberSettingsForm";s:6:"delete";s:45:"Drupal\sms\Form\PhoneNumberSettingsDeleteForm";}s:6:"access";s:45:"Drupal\Core\Entity\EntityAccessControlHandler";s:7:"storage";s:45:"Drupal\Core\Config\Entity\ConfigEntityStorage";s:11:"inline_form";s:48:"\Drupal\inline_entity_form\Form\EntityInlineForm";}s:19:" * admin_permission";s:23:"administer smsframework";s:25:" * permission_granularity";s:11:"entity_type";s:8:" * links";a:3:{s:9:"canonical";s:63:"/admin/config/smsframework/phone_number/{phone_number_settings}";s:9:"edit-form";s:63:"/admin/config/smsframework/phone_number/{phone_number_settings}";s:11:"delete-form";s:70:"/admin/config/smsframework/phone_number/{phone_number_settings}/delete";}s:17:" * label_callback";N;s:21:" * bundle_entity_type";N;s:12:" * bundle_of";N;s:15:" * bundle_label";N;s:13:" * base_table";N;s:22:" * revision_data_table";N;s:17:" * revision_table";N;s:13:" * data_table";N;s:15:" * translatable";b:0;s:8:" * label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:21:"Phone number settings";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:17:" * label_singular";s:0:"";s:15:" * label_plural";s:0:"";s:14:" * label_count";a:0:{}s:15:" * uri_callback";N;s:8:" * group";s:13:"configuration";s:14:" * group_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:13:"Configuration";s:12:" * arguments";a:0:{}s:10:" * options";a:1:{s:7:"context";s:17:"Entity type group";}}s:22:" * field_ui_base_route";N;s:26:" * common_reference_target";b:0;s:22:" * list_cache_contexts";a:0:{}s:18:" * list_cache_tags";a:1:{i:0;s:33:"config:phone_number_settings_list";}s:14:" * constraints";a:0:{}s:13:" * additional";a:0:{}s:20:" * stringTranslation";N;}',
  ))
  ->values(array(
    'collection' => 'entity.definitions.installed',
    'name' => 'sms.entity_type',
    'value' => 'O:36:"Drupal\Core\Entity\ContentEntityType":35:{s:15:" * static_cache";b:1;s:15:" * render_cache";b:1;s:19:" * persistent_cache";b:1;s:14:" * entity_keys";a:6:{s:2:"id";s:2:"id";s:4:"uuid";s:4:"uuid";s:8:"revision";s:0:"";s:6:"bundle";s:0:"";s:8:"langcode";s:0:"";s:16:"default_langcode";s:16:"default_langcode";}s:5:" * id";s:3:"sms";s:11:" * provider";s:3:"sms";s:8:" * class";s:28:"Drupal\sms\Entity\SmsMessage";s:16:" * originalClass";N;s:11:" * handlers";a:5:{s:10:"views_data";s:36:"Drupal\sms\Views\SmsMessageViewsData";s:6:"access";s:45:"Drupal\Core\Entity\EntityAccessControlHandler";s:7:"storage";s:46:"Drupal\Core\Entity\Sql\SqlContentEntityStorage";s:12:"view_builder";s:36:"Drupal\Core\Entity\EntityViewBuilder";s:11:"inline_form";s:48:"\Drupal\inline_entity_form\Form\EntityInlineForm";}s:19:" * admin_permission";N;s:25:" * permission_granularity";s:11:"entity_type";s:8:" * links";a:0:{}s:17:" * label_callback";N;s:21:" * bundle_entity_type";N;s:12:" * bundle_of";N;s:15:" * bundle_label";N;s:13:" * base_table";s:3:"sms";s:22:" * revision_data_table";N;s:17:" * revision_table";N;s:13:" * data_table";N;s:15:" * translatable";b:0;s:8:" * label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:11:"SMS Message";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:17:" * label_singular";s:0:"";s:15:" * label_plural";s:0:"";s:14:" * label_count";a:0:{}s:15:" * uri_callback";N;s:8:" * group";s:7:"content";s:14:" * group_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:7:"Content";s:12:" * arguments";a:0:{}s:10:" * options";a:1:{s:7:"context";s:17:"Entity type group";}}s:22:" * field_ui_base_route";N;s:26:" * common_reference_target";b:0;s:22:" * list_cache_contexts";a:0:{}s:18:" * list_cache_tags";a:1:{i:0;s:8:"sms_list";}s:14:" * constraints";a:0:{}s:13:" * additional";a:0:{}s:20:" * stringTranslation";N;}',
  ))
  ->values(array(
    'collection' => 'entity.definitions.installed',
    'name' => 'sms.field_storage_definitions',
    'value' => 'a:16:{s:2:"id";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"integer";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:4:"size";s:6:"normal";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:2;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:integer";s:8:"settings";a:6:{s:8:"unsigned";b:1;s:4:"size";s:6:"normal";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:14:"SMS message ID";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:19:"The SMS message ID.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"read-only";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:2:"id";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:4:"uuid";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:4:"uuid";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:13:"varchar_ascii";s:6:"length";i:128;s:6:"binary";b:0;}}s:11:"unique keys";a:1:{s:5:"value";a:1:{i:0;s:5:"value";}}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:39;s:13:" * definition";a:2:{s:4:"type";s:15:"field_item:uuid";s:8:"settings";a:3:{s:10:"max_length";i:128;s:8:"is_ascii";b:1;s:14:"case_sensitive";b:0;}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:4:"UUID";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:21:"The SMS message UUID.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"read-only";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:4:"uuid";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:7:"gateway";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:16:"entity_reference";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:9:"target_id";a:3:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:13:"varchar_ascii";s:6:"length";i:255;}}s:7:"indexes";a:1:{s:9:"target_id";a:1:{i:0;s:9:"target_id";}}s:11:"unique keys";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:75;s:13:" * definition";a:2:{s:4:"type";s:27:"field_item:entity_reference";s:8:"settings";a:3:{s:11:"target_type";s:11:"sms_gateway";s:7:"handler";s:7:"default";s:16:"handler_settings";a:0:{}}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:14:"Gateway Plugin";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:28:"The gateway plugin instance.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"read-only";b:1;s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:7:"gateway";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:9:"direction";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"integer";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:3:"int";s:8:"unsigned";b:0;s:4:"size";s:4:"tiny";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:112;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:integer";s:8:"settings";a:6:{s:8:"unsigned";b:0;s:4:"size";s:4:"tiny";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:22:"Transmission direction";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:61:"Transmission direction, See SmsMessageInterface::DIRECTION_*.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"read-only";b:1;s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:9:"direction";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:11:"sender_name";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:6:"string";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:7:"varchar";s:6:"length";i:255;s:6:"binary";b:0;}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:150;s:13:" * definition";a:2:{s:4:"type";s:17:"field_item:string";s:8:"settings";a:3:{s:10:"max_length";i:255;s:8:"is_ascii";b:0;s:14:"case_sensitive";b:0;}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:11:"Sender name";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:23:"The name of the sender.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:0;s:8:"provider";s:3:"sms";s:10:"field_name";s:11:"sender_name";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:19:"sender_phone_number";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:9:"telephone";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:2:{s:4:"type";s:7:"varchar";s:6:"length";i:256;}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:184;s:13:" * definition";a:2:{s:4:"type";s:20:"field_item:telephone";s:8:"settings";a:0:{}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:19:"Sender phone number";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:31:"The phone number of the sender.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:13:"default_value";a:1:{i:0;a:1:{s:5:"value";s:0:"";}}s:8:"required";b:0;s:8:"provider";s:3:"sms";s:10:"field_name";s:19:"sender_phone_number";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:13:"sender_entity";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:24:"dynamic_entity_reference";s:9:" * schema";a:4:{s:7:"columns";a:2:{s:9:"target_id";a:3:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:3:"int";s:8:"unsigned";b:1;}s:11:"target_type";a:3:{s:11:"description";s:40:"The Entity Type ID of the target entity.";s:4:"type";s:7:"varchar";s:6:"length";i:32;}}s:7:"indexes";a:1:{s:9:"target_id";a:2:{i:0;s:9:"target_id";i:1;s:11:"target_type";}}s:11:"unique keys";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:217;s:13:" * definition";a:2:{s:4:"type";s:35:"field_item:dynamic_entity_reference";s:8:"settings";a:14:{s:20:"exclude_entity_types";b:1;s:15:"entity_type_ids";a:0:{}s:7:"comment";a:2:{s:7:"handler";s:15:"default:comment";s:16:"handler_settings";a:0:{}}s:15:"contact_message";a:2:{s:7:"handler";s:23:"default:contact_message";s:16:"handler_settings";a:0:{}}s:4:"node";a:2:{s:7:"handler";s:12:"default:node";s:16:"handler_settings";a:0:{}}s:13:"block_content";a:2:{s:7:"handler";s:21:"default:block_content";s:16:"handler_settings";a:0:{}}s:17:"menu_link_content";a:2:{s:7:"handler";s:25:"default:menu_link_content";s:16:"handler_settings";a:0:{}}s:4:"file";a:2:{s:7:"handler";s:12:"default:file";s:16:"handler_settings";a:0:{}}s:9:"paragraph";a:2:{s:7:"handler";s:17:"default:paragraph";s:16:"handler_settings";a:0:{}}s:29:"sms_phone_number_verification";a:2:{s:7:"handler";s:37:"default:sms_phone_number_verification";s:16:"handler_settings";a:0:{}}s:3:"sms";a:2:{s:7:"handler";s:11:"default:sms";s:16:"handler_settings";a:0:{}}s:8:"shortcut";a:2:{s:7:"handler";s:16:"default:shortcut";s:16:"handler_settings";a:0:{}}s:13:"taxonomy_term";a:2:{s:7:"handler";s:21:"default:taxonomy_term";s:16:"handler_settings";a:0:{}}s:4:"user";a:2:{s:7:"handler";s:12:"default:user";s:16:"handler_settings";a:0:{}}}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:13:"Sender entity";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:36:"The entity who sent the SMS message.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:0;s:8:"provider";s:3:"sms";s:10:"field_name";s:13:"sender_entity";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:22:"recipient_phone_number";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:9:"telephone";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:2:{s:4:"type";s:7:"varchar";s:6:"length";i:256;}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:293;s:13:" * definition";a:2:{s:4:"type";s:20:"field_item:telephone";s:8:"settings";a:0:{}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:22:"Recipient phone number";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:34:"The phone number of the recipient.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:0;s:11:"cardinality";i:-1;s:8:"provider";s:3:"sms";s:10:"field_name";s:22:"recipient_phone_number";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:16:"recipient_entity";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:24:"dynamic_entity_reference";s:9:" * schema";a:4:{s:7:"columns";a:2:{s:9:"target_id";a:3:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:3:"int";s:8:"unsigned";b:1;}s:11:"target_type";a:3:{s:11:"description";s:40:"The Entity Type ID of the target entity.";s:4:"type";s:7:"varchar";s:6:"length";i:32;}}s:7:"indexes";a:1:{s:9:"target_id";a:2:{i:0;s:9:"target_id";i:1;s:11:"target_type";}}s:11:"unique keys";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:324;s:13:" * definition";a:2:{s:4:"type";s:35:"field_item:dynamic_entity_reference";s:8:"settings";a:14:{s:20:"exclude_entity_types";b:1;s:15:"entity_type_ids";a:0:{}s:7:"comment";a:2:{s:7:"handler";s:15:"default:comment";s:16:"handler_settings";a:0:{}}s:15:"contact_message";a:2:{s:7:"handler";s:23:"default:contact_message";s:16:"handler_settings";a:0:{}}s:4:"node";a:2:{s:7:"handler";s:12:"default:node";s:16:"handler_settings";a:0:{}}s:13:"block_content";a:2:{s:7:"handler";s:21:"default:block_content";s:16:"handler_settings";a:0:{}}s:17:"menu_link_content";a:2:{s:7:"handler";s:25:"default:menu_link_content";s:16:"handler_settings";a:0:{}}s:4:"file";a:2:{s:7:"handler";s:12:"default:file";s:16:"handler_settings";a:0:{}}s:9:"paragraph";a:2:{s:7:"handler";s:17:"default:paragraph";s:16:"handler_settings";a:0:{}}s:29:"sms_phone_number_verification";a:2:{s:7:"handler";s:37:"default:sms_phone_number_verification";s:16:"handler_settings";a:0:{}}s:3:"sms";a:2:{s:7:"handler";s:11:"default:sms";s:16:"handler_settings";a:0:{}}s:8:"shortcut";a:2:{s:7:"handler";s:16:"default:shortcut";s:16:"handler_settings";a:0:{}}s:13:"taxonomy_term";a:2:{s:7:"handler";s:21:"default:taxonomy_term";s:16:"handler_settings";a:0:{}}s:4:"user";a:2:{s:7:"handler";s:12:"default:user";s:16:"handler_settings";a:0:{}}}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:16:"Recipient entity";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:40:"The entity who received the SMS message.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:0;s:8:"provider";s:3:"sms";s:10:"field_name";s:16:"recipient_entity";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:7:"options";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:3:"map";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:4:"blob";s:4:"size";s:3:"big";s:9:"serialize";b:1;}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:400;s:13:" * definition";a:2:{s:4:"type";s:14:"field_item:map";s:8:"settings";a:0:{}}}s:13:" * definition";a:6:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:7:"Options";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:31:"Options to pass to the gateway.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"provider";s:3:"sms";s:10:"field_name";s:7:"options";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:9:"automated";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"boolean";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:2:{s:4:"type";s:3:"int";s:4:"size";s:4:"tiny";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:430;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:boolean";s:8:"settings";a:2:{s:8:"on_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:9:"Automated";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"off_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:13:"Not automated";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:12:"Is automated";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:108:"Whether this SMS message was generated automatically. 0=generated by user action, 1=generated automatically.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:13:"default_value";a:1:{i:0;a:1:{s:5:"value";b:1;}}s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:9:"automated";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:6:"queued";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"boolean";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:2:{s:4:"type";s:3:"int";s:4:"size";s:4:"tiny";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:471;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:boolean";s:8:"settings";a:2:{s:8:"on_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:6:"Queued";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"off_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:10:"Not queued";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:6:"Queued";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:56:"Whether the SMS message is in the queue to be processed.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:13:"default_value";a:1:{i:0;a:1:{s:5:"value";b:0;}}s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:6:"queued";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:7:"created";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"created";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:1:{s:4:"type";s:3:"int";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:512;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:created";s:8:"settings";a:0:{}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:13:"Creation date";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:37:"The time the SMS message was created.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:7:"created";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:7:"send_on";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"created";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:1:{s:4:"type";s:3:"int";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:541;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:created";s:8:"settings";a:0:{}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:9:"Send date";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:33:"The time to send the SMS message.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:7:"send_on";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:9:"processed";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:9:"timestamp";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:1:{s:4:"type";s:3:"int";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:570;s:13:" * definition";a:2:{s:4:"type";s:20:"field_item:timestamp";s:8:"settings";a:0:{}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:9:"Processed";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:142:"The time the SMS message was processed. This value does not indicate whether the message was sent, only that the gateway accepted the request.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:0;s:8:"provider";s:3:"sms";s:10:"field_name";s:9:"processed";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}s:7:"message";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:11:"string_long";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:2:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:599;s:13:" * definition";a:2:{s:4:"type";s:22:"field_item:string_long";s:8:"settings";a:1:{s:14:"case_sensitive";b:0;}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:7:"Message";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:16:"The SMS message.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:13:"default_value";a:1:{i:0;a:1:{s:5:"value";s:0:"";}}s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:7:"message";s:11:"entity_type";s:3:"sms";s:6:"bundle";N;}}}',
  ))
  ->values(array(
    'collection' => 'entity.definitions.installed',
    'name' => 'sms_gateway.entity_type',
    'value' => 'O:42:"Drupal\Core\Config\Entity\ConfigEntityType":39:{s:16:" * config_prefix";s:7:"gateway";s:15:" * static_cache";b:0;s:14:" * lookup_keys";a:1:{i:0;s:4:"uuid";}s:16:" * config_export";a:0:{}s:21:" * mergedConfigExport";a:0:{}s:15:" * render_cache";b:1;s:19:" * persistent_cache";b:1;s:14:" * entity_keys";a:7:{s:2:"id";s:2:"id";s:5:"label";s:5:"label";s:8:"revision";s:0:"";s:6:"bundle";s:0:"";s:8:"langcode";s:8:"langcode";s:16:"default_langcode";s:16:"default_langcode";s:4:"uuid";s:4:"uuid";}s:5:" * id";s:11:"sms_gateway";s:11:" * provider";s:3:"sms";s:8:" * class";s:28:"Drupal\sms\Entity\SmsGateway";s:16:" * originalClass";N;s:11:" * handlers";a:5:{s:12:"list_builder";s:39:"\Drupal\sms\Lists\SmsGatewayListBuilder";s:4:"form";a:4:{s:3:"add";s:30:"Drupal\sms\Form\SmsGatewayForm";s:7:"default";s:30:"Drupal\sms\Form\SmsGatewayForm";s:4:"edit";s:30:"Drupal\sms\Form\SmsGatewayForm";s:6:"delete";s:36:"Drupal\sms\Form\SmsGatewayDeleteForm";}s:6:"access";s:45:"Drupal\Core\Entity\EntityAccessControlHandler";s:7:"storage";s:45:"Drupal\Core\Config\Entity\ConfigEntityStorage";s:11:"inline_form";s:48:"\Drupal\inline_entity_form\Form\EntityInlineForm";}s:19:" * admin_permission";s:23:"administer smsframework";s:25:" * permission_granularity";s:11:"entity_type";s:8:" * links";a:3:{s:9:"canonical";s:49:"/admin/config/smsframework/gateways/{sms_gateway}";s:9:"edit-form";s:49:"/admin/config/smsframework/gateways/{sms_gateway}";s:11:"delete-form";s:56:"/admin/config/smsframework/gateways/{sms_gateway}/delete";}s:17:" * label_callback";N;s:21:" * bundle_entity_type";N;s:12:" * bundle_of";N;s:15:" * bundle_label";N;s:13:" * base_table";N;s:22:" * revision_data_table";N;s:17:" * revision_table";N;s:13:" * data_table";N;s:15:" * translatable";b:0;s:8:" * label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:11:"SMS Gateway";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:17:" * label_singular";s:0:"";s:15:" * label_plural";s:0:"";s:14:" * label_count";a:0:{}s:15:" * uri_callback";N;s:8:" * group";s:13:"configuration";s:14:" * group_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:13:"Configuration";s:12:" * arguments";a:0:{}s:10:" * options";a:1:{s:7:"context";s:17:"Entity type group";}}s:22:" * field_ui_base_route";N;s:26:" * common_reference_target";b:0;s:22:" * list_cache_contexts";a:0:{}s:18:" * list_cache_tags";a:1:{i:0;s:23:"config:sms_gateway_list";}s:14:" * constraints";a:0:{}s:13:" * additional";a:0:{}s:20:" * stringTranslation";N;}',
  ))
  ->values(array(
    'collection' => 'entity.definitions.installed',
    'name' => 'sms_phone_number_verification.entity_type',
    'value' => 'O:36:"Drupal\Core\Entity\ContentEntityType":35:{s:15:" * static_cache";b:1;s:15:" * render_cache";b:1;s:19:" * persistent_cache";b:1;s:14:" * entity_keys";a:5:{s:2:"id";s:2:"id";s:8:"revision";s:0:"";s:6:"bundle";s:0:"";s:8:"langcode";s:0:"";s:16:"default_langcode";s:16:"default_langcode";}s:5:" * id";s:29:"sms_phone_number_verification";s:11:" * provider";s:3:"sms";s:8:" * class";s:41:"Drupal\sms\Entity\PhoneNumberVerification";s:16:" * originalClass";N;s:11:" * handlers";a:4:{s:6:"access";s:45:"Drupal\Core\Entity\EntityAccessControlHandler";s:7:"storage";s:46:"Drupal\Core\Entity\Sql\SqlContentEntityStorage";s:12:"view_builder";s:36:"Drupal\Core\Entity\EntityViewBuilder";s:11:"inline_form";s:48:"\Drupal\inline_entity_form\Form\EntityInlineForm";}s:19:" * admin_permission";N;s:25:" * permission_granularity";s:11:"entity_type";s:8:" * links";a:0:{}s:17:" * label_callback";N;s:21:" * bundle_entity_type";N;s:12:" * bundle_of";N;s:15:" * bundle_label";N;s:13:" * base_table";s:29:"sms_phone_number_verification";s:22:" * revision_data_table";N;s:17:" * revision_table";N;s:13:" * data_table";N;s:15:" * translatable";b:0;s:8:" * label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:25:"Phone Number Verification";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:17:" * label_singular";s:0:"";s:15:" * label_plural";s:0:"";s:14:" * label_count";a:0:{}s:15:" * uri_callback";N;s:8:" * group";s:7:"content";s:14:" * group_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:7:"Content";s:12:" * arguments";a:0:{}s:10:" * options";a:1:{s:7:"context";s:17:"Entity type group";}}s:22:" * field_ui_base_route";N;s:26:" * common_reference_target";b:0;s:22:" * list_cache_contexts";a:0:{}s:18:" * list_cache_tags";a:1:{i:0;s:34:"sms_phone_number_verification_list";}s:14:" * constraints";a:0:{}s:13:" * additional";a:0:{}s:20:" * stringTranslation";N;}',
  ))
  ->values(array(
    'collection' => 'entity.definitions.installed',
    'name' => 'sms_phone_number_verification.field_storage_definitions',
    'value' => 'a:7:{s:2:"id";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"integer";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:4:"size";s:6:"normal";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:2;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:integer";s:8:"settings";a:6:{s:8:"unsigned";b:1;s:4:"size";s:6:"normal";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";}}}s:13:" * definition";a:7:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:21:"Phone verification ID";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:26:"The phone verification ID.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"read-only";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:2:"id";s:11:"entity_type";s:29:"sms_phone_number_verification";s:6:"bundle";N;}}s:6:"entity";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:24:"dynamic_entity_reference";s:9:" * schema";a:4:{s:7:"columns";a:2:{s:9:"target_id";a:3:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:3:"int";s:8:"unsigned";b:1;}s:11:"target_type";a:3:{s:11:"description";s:40:"The Entity Type ID of the target entity.";s:4:"type";s:7:"varchar";s:6:"length";i:32;}}s:7:"indexes";a:1:{s:9:"target_id";a:2:{i:0;s:9:"target_id";i:1;s:11:"target_type";}}s:11:"unique keys";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:39;s:13:" * definition";a:2:{s:4:"type";s:35:"field_item:dynamic_entity_reference";s:8:"settings";a:14:{s:20:"exclude_entity_types";b:1;s:15:"entity_type_ids";a:0:{}s:7:"comment";a:2:{s:7:"handler";s:15:"default:comment";s:16:"handler_settings";a:0:{}}s:15:"contact_message";a:2:{s:7:"handler";s:23:"default:contact_message";s:16:"handler_settings";a:0:{}}s:4:"node";a:2:{s:7:"handler";s:12:"default:node";s:16:"handler_settings";a:0:{}}s:13:"block_content";a:2:{s:7:"handler";s:21:"default:block_content";s:16:"handler_settings";a:0:{}}s:17:"menu_link_content";a:2:{s:7:"handler";s:25:"default:menu_link_content";s:16:"handler_settings";a:0:{}}s:4:"file";a:2:{s:7:"handler";s:12:"default:file";s:16:"handler_settings";a:0:{}}s:9:"paragraph";a:2:{s:7:"handler";s:17:"default:paragraph";s:16:"handler_settings";a:0:{}}s:29:"sms_phone_number_verification";a:2:{s:7:"handler";s:37:"default:sms_phone_number_verification";s:16:"handler_settings";a:0:{}}s:3:"sms";a:2:{s:7:"handler";s:11:"default:sms";s:16:"handler_settings";a:0:{}}s:8:"shortcut";a:2:{s:7:"handler";s:16:"default:shortcut";s:16:"handler_settings";a:0:{}}s:13:"taxonomy_term";a:2:{s:7:"handler";s:21:"default:taxonomy_term";s:16:"handler_settings";a:0:{}}s:4:"user";a:2:{s:7:"handler";s:12:"default:user";s:16:"handler_settings";a:0:{}}}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:6:"Entity";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:38:"The entity for this verification code.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:1;s:9:"read-only";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:6:"entity";s:11:"entity_type";s:29:"sms_phone_number_verification";s:6:"bundle";N;}}s:6:"bundle";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:6:"string";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:7:"varchar";s:6:"length";i:255;s:6:"binary";b:0;}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:116;s:13:" * definition";a:2:{s:4:"type";s:17:"field_item:string";s:8:"settings";a:3:{s:10:"max_length";i:255;s:8:"is_ascii";b:0;s:14:"case_sensitive";b:0;}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:6:"Bundle";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:25:"The bundle of the entity.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:1;s:9:"read-only";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:6:"bundle";s:11:"entity_type";s:29:"sms_phone_number_verification";s:6:"bundle";N;}}s:5:"phone";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:9:"telephone";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:2:{s:4:"type";s:7:"varchar";s:6:"length";i:256;}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:151;s:13:" * definition";a:2:{s:4:"type";s:20:"field_item:telephone";s:8:"settings";a:0:{}}}s:13:" * definition";a:9:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:5:"Phone";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:13:"Phone number.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:13:"default_value";a:1:{i:0;a:1:{s:5:"value";s:0:"";}}s:11:"cardinality";i:1;s:7:"display";a:1:{s:4:"form";a:1:{s:7:"options";a:1:{s:4:"type";s:6:"hidden";}}}s:8:"provider";s:3:"sms";s:10:"field_name";s:5:"phone";s:11:"entity_type";s:29:"sms_phone_number_verification";s:6:"bundle";N;}}s:4:"code";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:6:"string";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:3:{s:4:"type";s:7:"varchar";s:6:"length";i:255;s:6:"binary";b:0;}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:188;s:13:" * definition";a:2:{s:4:"type";s:17:"field_item:string";s:8:"settings";a:3:{s:10:"max_length";i:255;s:8:"is_ascii";b:0;s:14:"case_sensitive";b:0;}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:17:"Verification code";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:32:"The generated verification code.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"required";b:1;s:13:"default_value";a:1:{i:0;a:1:{s:5:"value";s:0:"";}}s:8:"provider";s:3:"sms";s:10:"field_name";s:4:"code";s:11:"entity_type";s:29:"sms_phone_number_verification";s:6:"bundle";N;}}s:7:"created";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"created";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:1:{s:4:"type";s:3:"int";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:225;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:created";s:8:"settings";a:0:{}}}s:13:" * definition";a:6:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:10:"Created on";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:48:"The time that the verification code was created.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:8:"provider";s:3:"sms";s:10:"field_name";s:7:"created";s:11:"entity_type";s:29:"sms_phone_number_verification";s:6:"bundle";N;}}s:6:"status";O:37:"Drupal\Core\Field\BaseFieldDefinition":5:{s:7:" * type";s:7:"boolean";s:9:" * schema";a:4:{s:7:"columns";a:1:{s:5:"value";a:2:{s:4:"type";s:3:"int";s:4:"size";s:4:"tiny";}}s:11:"unique keys";a:0:{}s:7:"indexes";a:0:{}s:12:"foreign keys";a:0:{}}s:10:" * indexes";a:0:{}s:17:" * itemDefinition";O:51:"Drupal\Core\Field\TypedData\FieldItemDataDefinition":2:{s:18:" * fieldDefinition";r:253;s:13:" * definition";a:2:{s:4:"type";s:18:"field_item:boolean";s:8:"settings";a:2:{s:8:"on_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:2:"On";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:9:"off_label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:3:"Off";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}}}}s:13:" * definition";a:8:{s:5:"label";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:6:"Status";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:11:"description";O:48:"Drupal\Core\StringTranslation\TranslatableMarkup":3:{s:9:" * string";s:48:"Verification status. 0=not verified, 1=verified.";s:12:" * arguments";a:0:{}s:10:" * options";a:0:{}}s:13:"default_value";a:1:{i:0;a:1:{s:5:"value";b:0;}}s:8:"required";b:1;s:8:"provider";s:3:"sms";s:10:"field_name";s:6:"status";s:11:"entity_type";s:29:"sms_phone_number_verification";s:6:"bundle";N;}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.entity_schema_data',
    'value' => 'a:1:{s:3:"sms";a:1:{s:11:"primary key";a:1:{i:0;s:2:"id";}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.automated',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:9:"automated";a:3:{s:4:"type";s:3:"int";s:4:"size";s:4:"tiny";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.created',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:7:"created";a:2:{s:4:"type";s:3:"int";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.direction',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:9:"direction";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:0;s:4:"size";s:4:"tiny";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.gateway',
    'value' => 'a:1:{s:3:"sms";a:2:{s:6:"fields";a:1:{s:7:"gateway";a:4:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:13:"varchar_ascii";s:6:"length";i:255;s:8:"not null";b:0;}}s:7:"indexes";a:1:{s:29:"sms_field__gateway__target_id";a:1:{i:0;s:7:"gateway";}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.id',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:2:"id";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:4:"size";s:6:"normal";s:8:"not null";b:1;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.message',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:7:"message";a:3:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.options',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:7:"options";a:4:{s:4:"type";s:4:"blob";s:4:"size";s:3:"big";s:9:"serialize";b:1;s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.processed',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:9:"processed";a:2:{s:4:"type";s:3:"int";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.queued',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:6:"queued";a:3:{s:4:"type";s:3:"int";s:4:"size";s:4:"tiny";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.recipient_entity',
    'value' => 'a:1:{s:3:"sms";a:2:{s:6:"fields";a:2:{s:27:"recipient_entity__target_id";a:4:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:0;}s:29:"recipient_entity__target_type";a:4:{s:11:"description";s:40:"The Entity Type ID of the target entity.";s:4:"type";s:7:"varchar";s:6:"length";i:32;s:8:"not null";b:0;}}s:7:"indexes";a:1:{s:38:"sms_field__recipient_entity__target_id";a:2:{i:0;s:27:"recipient_entity__target_id";i:1;s:29:"recipient_entity__target_type";}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.recipient_phone_number',
    'value' => 'a:1:{s:27:"sms__recipient_phone_number";a:4:{s:11:"description";s:50:"Data storage for sms field recipient_phone_number.";s:6:"fields";a:7:{s:6:"bundle";a:5:{s:4:"type";s:13:"varchar_ascii";s:6:"length";i:128;s:8:"not null";b:1;s:7:"default";s:0:"";s:11:"description";s:88:"The field instance bundle to which this row belongs, used when deleting a field instance";}s:7:"deleted";a:5:{s:4:"type";s:3:"int";s:4:"size";s:4:"tiny";s:8:"not null";b:1;s:7:"default";i:0;s:11:"description";s:60:"A boolean indicating whether this data item has been deleted";}s:9:"entity_id";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:1;s:11:"description";s:38:"The entity id this data is attached to";}s:11:"revision_id";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:1;s:11:"description";s:114:"The entity revision id this data is attached to, which for an unversioned entity type is the same as the entity id";}s:8:"langcode";a:5:{s:4:"type";s:13:"varchar_ascii";s:6:"length";i:32;s:8:"not null";b:1;s:7:"default";s:0:"";s:11:"description";s:37:"The language code for this data item.";}s:5:"delta";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:1;s:11:"description";s:67:"The sequence number for this data item, used for multi-value fields";}s:28:"recipient_phone_number_value";a:3:{s:4:"type";s:7:"varchar";s:6:"length";i:256;s:8:"not null";b:1;}}s:11:"primary key";a:4:{i:0;s:9:"entity_id";i:1;s:7:"deleted";i:2;s:5:"delta";i:3;s:8:"langcode";}s:7:"indexes";a:2:{s:6:"bundle";a:1:{i:0;s:6:"bundle";}s:11:"revision_id";a:1:{i:0;s:11:"revision_id";}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.sender_entity',
    'value' => 'a:1:{s:3:"sms";a:2:{s:6:"fields";a:2:{s:24:"sender_entity__target_id";a:4:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:0;}s:26:"sender_entity__target_type";a:4:{s:11:"description";s:40:"The Entity Type ID of the target entity.";s:4:"type";s:7:"varchar";s:6:"length";i:32;s:8:"not null";b:0;}}s:7:"indexes";a:1:{s:35:"sms_field__sender_entity__target_id";a:2:{i:0;s:24:"sender_entity__target_id";i:1;s:26:"sender_entity__target_type";}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.sender_name',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:11:"sender_name";a:4:{s:4:"type";s:7:"varchar";s:6:"length";i:255;s:6:"binary";b:0;s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.sender_phone_number',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:19:"sender_phone_number";a:3:{s:4:"type";s:7:"varchar";s:6:"length";i:256;s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.send_on',
    'value' => 'a:1:{s:3:"sms";a:1:{s:6:"fields";a:1:{s:7:"send_on";a:2:{s:4:"type";s:3:"int";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms.field_schema_data.uuid',
    'value' => 'a:1:{s:3:"sms";a:2:{s:6:"fields";a:1:{s:4:"uuid";a:4:{s:4:"type";s:13:"varchar_ascii";s:6:"length";i:128;s:6:"binary";b:0;s:8:"not null";b:1;}}s:11:"unique keys";a:1:{s:22:"sms_field__uuid__value";a:1:{i:0;s:4:"uuid";}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.entity_schema_data',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:1:{s:11:"primary key";a:1:{i:0;s:2:"id";}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.field_schema_data.bundle',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:1:{s:6:"fields";a:1:{s:6:"bundle";a:4:{s:4:"type";s:7:"varchar";s:6:"length";i:255;s:6:"binary";b:0;s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.field_schema_data.code',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:1:{s:6:"fields";a:1:{s:4:"code";a:4:{s:4:"type";s:7:"varchar";s:6:"length";i:255;s:6:"binary";b:0;s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.field_schema_data.created',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:1:{s:6:"fields";a:1:{s:7:"created";a:2:{s:4:"type";s:3:"int";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.field_schema_data.entity',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:2:{s:6:"fields";a:2:{s:17:"entity__target_id";a:4:{s:11:"description";s:28:"The ID of the target entity.";s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:0;}s:19:"entity__target_type";a:4:{s:11:"description";s:40:"The Entity Type ID of the target entity.";s:4:"type";s:7:"varchar";s:6:"length";i:32;s:8:"not null";b:0;}}s:7:"indexes";a:1:{s:41:"sms_phone_number_verification__ddcb6f92a1";a:2:{i:0;s:17:"entity__target_id";i:1;s:19:"entity__target_type";}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.field_schema_data.id',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:1:{s:6:"fields";a:1:{s:2:"id";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:4:"size";s:6:"normal";s:8:"not null";b:1;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.field_schema_data.phone',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:1:{s:6:"fields";a:1:{s:5:"phone";a:3:{s:4:"type";s:7:"varchar";s:6:"length";i:256;s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'entity.storage_schema.sql',
    'name' => 'sms_phone_number_verification.field_schema_data.status',
    'value' => 'a:1:{s:29:"sms_phone_number_verification";a:1:{s:6:"fields";a:1:{s:6:"status";a:3:{s:4:"type";s:3:"int";s:4:"size";s:4:"tiny";s:8:"not null";b:0;}}}}',
  ))
  ->values(array(
    'collection' => 'post_update',
    'name' => 'existing_updates',
    'value' => 'a:16:{i:0;s:64:"system_post_update_recalculate_configuration_entity_dependencies";i:1;s:43:"field_post_update_email_widget_size_setting";i:2;s:50:"field_post_update_entity_reference_handler_setting";i:3;s:46:"field_post_update_save_custom_storage_property";i:4;s:54:"block_post_update_disable_blocks_with_missing_contexts";i:5;s:46:"views_post_update_cleanup_duplicate_views_data";i:6;s:46:"views_post_update_field_formatter_dependencies";i:7;s:36:"views_post_update_taxonomy_index_tid";i:8;s:46:"views_post_update_update_cacheability_metadata";i:9;s:42:"image_post_update_image_style_dependencies";i:10;s:42:"block_post_update_fix_negate_in_conditions";i:11;s:62:"contact_post_update_add_message_redirect_field_to_contact_form";i:12;s:56:"editor_post_update_clear_cache_for_file_reference_filter";i:13;s:39:"views_post_update_boolean_filter_values";i:14;s:41:"views_post_update_serializer_dependencies";i:15;s:63:"dynamic_entity_reference_post_update_field_storage_dependencies";}',
  ))
  ->values(array(
    'collection' => 'system.schema',
    'name' => 'dynamic_entity_reference',
    'value' => 'i:8000;',
  ))
  ->execute();

// Install entity schema.
$connection->schema()->createTable('sms', array(
  'fields' => array(
    'id' => array(
      'type' => 'serial',
      'not null' => TRUE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'uuid' => array(
      'type' => 'varchar_ascii',
      'not null' => TRUE,
      'length' => '128',
    ),
    'gateway' => array(
      'type' => 'varchar_ascii',
      'not null' => FALSE,
      'length' => '255',
    ),
    'direction' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'tiny',
    ),
    'sender_name' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '255',
    ),
    'sender_phone_number' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '256',
    ),
    'sender_entity__target_id' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'sender_entity__target_type' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '32',
    ),
    'recipient_entity__target_id' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'recipient_entity__target_type' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '32',
    ),
    'options' => array(
      'type' => 'blob',
      'not null' => FALSE,
      'size' => 'big',
    ),
    'automated' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'tiny',
    ),
    'queued' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'tiny',
    ),
    'created' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'normal',
    ),
    'send_on' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'normal',
    ),
    'processed' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'normal',
    ),
    'message' => array(
      'type' => 'text',
      'not null' => FALSE,
      'size' => 'big',
    ),
  ),
  'primary key' => array(
    'id',
  ),
  'unique keys' => array(
    'sms_field__uuid__value' => array(
      'uuid',
    ),
  ),
  'indexes' => array(
    'sms_field__gateway__target_id' => array(
      'gateway',
    ),
    'sms_field__sender_entity__target_id' => array(
      'sender_entity__target_id',
      'sender_entity__target_type',
    ),
    'sms_field__recipient_entity__target_id' => array(
      'recipient_entity__target_id',
      'recipient_entity__target_type',
    ),
  ),
  'mysql_character_set' => 'utf8mb4',
));

$connection->schema()->createTable('sms__recipient_phone_number', array(
  'fields' => array(
    'bundle' => array(
      'type' => 'varchar_ascii',
      'not null' => TRUE,
      'length' => '128',
      'default' => '',
    ),
    'deleted' => array(
      'type' => 'int',
      'not null' => TRUE,
      'size' => 'tiny',
      'default' => '0',
    ),
    'entity_id' => array(
      'type' => 'int',
      'not null' => TRUE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'revision_id' => array(
      'type' => 'int',
      'not null' => TRUE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'langcode' => array(
      'type' => 'varchar_ascii',
      'not null' => TRUE,
      'length' => '32',
      'default' => '',
    ),
    'delta' => array(
      'type' => 'int',
      'not null' => TRUE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'recipient_phone_number_value' => array(
      'type' => 'varchar',
      'not null' => TRUE,
      'length' => '256',
    ),
  ),
  'primary key' => array(
    'entity_id',
    'deleted',
    'delta',
    'langcode',
  ),
  'indexes' => array(
    'bundle' => array(
      'bundle',
    ),
    'revision_id' => array(
      'revision_id',
    ),
  ),
  'mysql_character_set' => 'utf8mb4',
));

$connection->schema()->createTable('sms_phone_number_verification', array(
  'fields' => array(
    'id' => array(
      'type' => 'serial',
      'not null' => TRUE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'entity__target_id' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'normal',
      'unsigned' => TRUE,
    ),
    'entity__target_type' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '32',
    ),
    'bundle' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '255',
    ),
    'phone' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '256',
    ),
    'code' => array(
      'type' => 'varchar',
      'not null' => FALSE,
      'length' => '255',
    ),
    'created' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'normal',
    ),
    'status' => array(
      'type' => 'int',
      'not null' => FALSE,
      'size' => 'tiny',
    ),
  ),
  'primary key' => array(
    'id',
  ),
  'indexes' => array(
    'sms_phone_number_verification__ddcb6f92a1' => array(
      'entity__target_id',
      'entity__target_type',
    ),
  ),
  'mysql_character_set' => 'utf8mb4',
));

// Insert one dummy SMS message.
$connection->insert('sms')
  ->fields(array(
    'uuid',
    'gateway',
    'direction',
    'sender_entity__target_id',
    'sender_entity__target_type',
    'sender_phone_number',
    'automated',
    'send_on',
    'processed',
    'message',
  ))
  ->values(array(
    'uuid' => '9f0a3c73-4ee4-43a9-8be5-188367b7005e',
    'gateway' => 'log',
    'direction' => '1',
    'sender_entity__target_id' => '1',
    'sender_entity__target_type' => 'user',
    'sender_phone_number' => '1234567890',
    'automated' => '1',
    'send_on' => time(),
    'processed' => time(),
    'message' => 'this is a test message',
  ))
  ->execute();

$connection->insert('sms__recipient_phone_number')
  ->fields(array(
    'bundle',
    'deleted',
    'entity_id',
    'revision_id',
    'langcode',
    'delta',
    'recipient_phone_number_value',
  ))
  ->values(array(
    'bundle' => 'sms',
    'deleted' => '0',
    'entity_id' => '1',
    'revision_id' => '1',
    'langcode' => 'und',
    'delta' => '0',
    'recipient_phone_number_value' => '324876543210',
  ))
  ->values(array(
    'bundle' => 'sms',
    'deleted' => '0',
    'entity_id' => '1',
    'revision_id' => '1',
    'langcode' => 'und',
    'delta' => '1',
    'recipient_phone_number_value' => '765432324810',
  ))
  ->execute();
